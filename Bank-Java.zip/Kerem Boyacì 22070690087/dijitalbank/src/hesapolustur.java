import javax.swing.*;
import java.awt.*;

public class hesapolustur extends JFrame {

    private final JTextField firstNameField;
    private final JTextField lastNameField;
    private final JTextField usernameField;
    private final JPasswordField passwordField;

    public hesapolustur() {
        // Hesap oluşturma penceresi için gerekli ayarlamalar
        setTitle("Hesap Oluştur");
        setSize(300, 200);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); // Pencereyi kapat ama programı kapatma
        setLocationRelativeTo(null);
        setResizable(false);

        // Panel oluştur
        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(5, 2, 10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        // Ad alanı
        panel.add(new JLabel("Ad:"));
        firstNameField = createTextField();
        panel.add(firstNameField);

        // Soyad alanı
        panel.add(new JLabel("Soyad:"));
        lastNameField = createTextField();
        panel.add(lastNameField);

        // Kullanıcı adı alanı
        panel.add(new JLabel("Kullanıcı Adı:"));
        usernameField = createTextField();
        panel.add(usernameField);

        // Şifre alanı
        panel.add(new JLabel("Şifre:"));
        passwordField = createPasswordField();
        panel.add(passwordField);

        // Hesap oluştur butonu
        JButton createButton = createButton("Hesap Oluştur");
        createButton.addActionListener(e -> createAccount());
        panel.add(createButton);

        // İptal butonu
        JButton cancelButton = createButton("İptal");
        cancelButton.addActionListener(e -> {
            // İptal butonuna tıklandığında yapılacak işlemler
            dispose(); // Pencereyi kapat
        });
        panel.add(cancelButton);

        // Paneli frame'e ekle
        add(panel);
    }

    private JTextField createTextField() {
        JTextField textField = new JTextField();
        textField.setFont(new Font("Arial", Font.PLAIN, 14));
        return textField;
    }

    private JPasswordField createPasswordField() {
        JPasswordField passwordField = new JPasswordField();
        passwordField.setFont(new Font("Arial", Font.PLAIN, 14));
        return passwordField;
    }

    private JButton createButton(String text) {
        JButton button = new JButton(text);
        button.setFont(new Font("Arial", Font.BOLD, 14));
        return button;
    }

    private void createAccount() {
        // Kullanıcıdan alınan bilgiler
        String firstName = firstNameField.getText();
        String lastName = lastNameField.getText();
        usernameField.getText();
        passwordField.getPassword();
        JOptionPane.showMessageDialog(this,
                "Hesap oluşturuldu!\nHoş Geldiniz, " + firstName + " " + lastName + "!",
                "Başarılı", JOptionPane.INFORMATION_MESSAGE);

        // Hesap oluşturulduktan sonra pencereyi kapat
        dispose();
    }

    public void gorunurYap() {
        // Pencereyi görünür yap
        setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(hesapolustur::new);
    }
}
