import javax.swing.*;
import java.awt.*;

public class Main extends JFrame {

    private final JTextField usernameField;
    private final JPasswordField passwordField;

    public Main() {
        // Frame ayarları
        setTitle("Ketemu Bank");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(500, 350);
        setLocationRelativeTo(null);
        setResizable(false);

        // Panel oluştur
        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(6, 2, 10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(50, 50, 50, 50));
        panel.setBackground(new Color(50, 67, 108)); // Açık mor renk

        // Başlık
        JLabel titleLabel = new JLabel("Ketemu Bank");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 24));
        titleLabel.setForeground(new Color(2, 0, 3));
        panel.add(titleLabel);
        panel.add(new JLabel());

        // Kullanıcı adı alanı
        panel.add(createLabel("Kullanıcı Adı:"));
        usernameField = createTextField();
        panel.add(usernameField);

        // Şifre alanı
        panel.add(createLabel("Şifre:"));
        passwordField = createPasswordField();
        panel.add(passwordField);

        // Giriş butonu
        JButton loginButton = createButton("Giriş Yap");
        loginButton.addActionListener(
                e -> checkLogin()
        );
        panel.add(loginButton);

        // Hesap oluştur butonu
        JButton createAccountButton = createButton("Hesap Oluştur");
        createAccountButton.addActionListener(e -> {
            // Hesap oluştur butonuna tıklandığında HesapOlustur sınıfını çağır
            hesapolustur hesapOlustur = new hesapolustur();
            hesapOlustur.gorunurYap();
        });
        panel.add(createAccountButton);

        // İptal butonu
        JButton cancelButton = createButton("İptal");
        cancelButton.addActionListener(e -> {
            dispose(); // Formu kapat
        });
        panel.add(cancelButton);

        // Paneli frame'e ekle
        add(panel);

        // Frame'i görünür yap
        setVisible(true);
    }

    private JLabel createLabel(String text) {
        JLabel label = new JLabel(text);
        label.setFont(new Font("Arial", Font.PLAIN, 18));
        label.setForeground(new Color(0, 0, 0));
        return label;
    }

    private JTextField createTextField() {
        JTextField textField = new JTextField();
        textField.setFont(new Font("Arial", Font.PLAIN, 18));
        textField.setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0)));
        return textField;
    }

    private JPasswordField createPasswordField() {
        JPasswordField passwordField = new JPasswordField();
        passwordField.setFont(new Font("Arial", Font.PLAIN, 18));
        passwordField.setBorder(BorderFactory.createLineBorder(new Color(3, 0, 3)));
        return passwordField;
    }

    private JButton createButton(String text) {
        JButton button = new JButton(text);
        button.setFont(new Font("Arial", Font.BOLD, 18));
        button.setForeground(Color.WHITE);
        button.setBackground(new Color(253, 0, 0));
        button.setFocusPainted(false);
        button.setBorderPainted(false);
        return button;
    }

    private void checkLogin() {
        // Kullanıcı adı ve şifre tanımları
        String correctUsername = "Kerem";
        String correctPassword = "kerem123";

        // Kullanıcıdan alınan bilgiler
        String enteredUsername = usernameField.getText();
        String enteredPassword = new String(passwordField.getPassword());

        // Kullanıcı bilgilerini kontrol etme
        if (correctUsername.equals(enteredUsername) && correctPassword.equals(enteredPassword)) {
            JOptionPane.showMessageDialog(this, "Giriş Başarılı. Hoş Geldiniz!", "Başarılı Giriş", JOptionPane.INFORMATION_MESSAGE);
            new sorulama();
        } else {
            JOptionPane.showMessageDialog(this,
                    "Giriş Başarısız. Lütfen Kullanıcı Adı ve Şifrenizi Kontrol Edin.",
                    "Başarısız Giriş", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(Main::new);
    }
}
