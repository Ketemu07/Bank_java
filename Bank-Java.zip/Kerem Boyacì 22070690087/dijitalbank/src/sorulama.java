import javax.swing.*;
import java.awt.*;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class sorulama extends JFrame {

    private final JLabel balanceLabel;
    private final JTextArea transactionHistoryArea;

    private final Map<String, Double> accountInfo;
    private final List<String> transactionHistory;

    public sorulama() {
        // Frame ayarları
        setTitle("Ketemu Bank");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(600, 500);
        setLocationRelativeTo(null);
        setResizable(false);

        // Hesap bilgilerini tutan harita
        accountInfo = new HashMap<>();
        accountInfo.put("user123", 1000.0); // Örnek bir başlangıç bakiyesi

        // İşlem geçmişini tutan liste
        transactionHistory = new ArrayList<>();

        // Ana panel
        JPanel mainPanel = new JPanel(new GridLayout(6, 1, 10, 10));

        // Kullanıcı adı ve bakiye paneli
        JPanel userInfoPanel = new JPanel(new GridLayout(1, 2));
        userInfoPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 0, 20));

        // Kullanıcı adı etiketi
        JLabel userLabel = new JLabel("Kullanıcı: Ketemu Bank kullanıcısı");
        userInfoPanel.add(userLabel);

        // Bakiye etiketi
        balanceLabel = new JLabel("Bakiye: $1000.0");
        userInfoPanel.add(balanceLabel);

        mainPanel.add(userInfoPanel);

        // Para Çek butonu
        JButton withdrawButton = createButton("Para Çek");
        withdrawButton.addActionListener(e -> withdrawMoney());
        mainPanel.add(withdrawButton);

        // Para Yatır butonu
        JButton depositButton = createButton("Para Yatır");
        depositButton.addActionListener(e -> depositMoney());
        mainPanel.add(depositButton);

        // Bakiye Sorgula butonu
        JButton checkBalanceButton = createButton("Bakiye Sorgula");
        checkBalanceButton.addActionListener(e -> checkBalance());
        mainPanel.add(checkBalanceButton);

        // İşlem geçmişi alanı
        transactionHistoryArea = new JTextArea();
        transactionHistoryArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(transactionHistoryArea);
        mainPanel.add(scrollPane);

        // Ana paneli frame'e ekle
        add(mainPanel);

        // Frame'i görünür yap
        setVisible(true);
    }

    private JButton createButton(String text) {
        JButton button = new JButton(text);
        button.setFont(new Font("Arial", Font.BOLD, 14));
        button.setBackground(new Color(50, 67, 108));
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setBorderPainted(false);
        return button;
    }

    private void withdrawMoney() {
        String username = "user123";
        double currentBalance = accountInfo.get(username);
        String amountStr = JOptionPane.showInputDialog(this, "Çekilecek Miktar:");

        try {
            double withdrawalAmount = Double.parseDouble(amountStr);

            if (withdrawalAmount > 0 && withdrawalAmount <= currentBalance) {
                currentBalance -= withdrawalAmount;
                accountInfo.put(username, currentBalance);
                updateInfoLabel();
                recordTransaction("Para Çekme", withdrawalAmount);
                JOptionPane.showMessageDialog(this, "Para çekme işlemi başarılı.");
            } else {
                JOptionPane.showMessageDialog(this, "Geçersiz miktar veya yetersiz bakiye!", "Hata", JOptionPane.ERROR_MESSAGE);
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Geçersiz miktar!", "Hata", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void depositMoney() {
        String username = "user123";
        double currentBalance = accountInfo.get(username);
        String amountStr = JOptionPane.showInputDialog(this, "Yatırılacak Miktar:");

        try {
            double depositAmount = Double.parseDouble(amountStr);

            if (depositAmount > 0) {
                currentBalance += depositAmount;
                accountInfo.put(username, currentBalance);
                updateInfoLabel();
                recordTransaction("Para Yatırma", depositAmount);
                JOptionPane.showMessageDialog(this, "Para yatırma işlemi başarılı.");
            } else {
                JOptionPane.showMessageDialog(this, "Geçersiz miktar!", "Hata", JOptionPane.ERROR_MESSAGE);
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Geçersiz miktar!", "Hata", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void checkBalance() {
        String username = "user123";
        double currentBalance = accountInfo.get(username);
        JOptionPane.showMessageDialog(this, "Bakiye: $" + currentBalance);
    }

    private void updateInfoLabel() {
        String username = "user123";
        double currentBalance = accountInfo.get(username);
        balanceLabel.setText("Bakiye: $" + currentBalance);
    }

    private void recordTransaction(String operation, double amount) {
        String transactionInfo = String.format("[%s] %s - Tarih: %s",
                operation,
                formatAmount(amount),
                getCurrentDateTime());
        transactionHistory.add(transactionInfo);
        updateTransactionHistory();
    }

    private String getCurrentDateTime() {
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
        return dateFormat.format(new Date());
    }

    private String formatAmount(double amount) {
        return String.format("$%.2f", amount);
    }

    private void updateTransactionHistory() {
        StringBuilder historyText = new StringBuilder();
        for (String transaction : transactionHistory) {
            historyText.append(transaction).append("\n");
        }
        transactionHistoryArea.setText(historyText.toString());
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(sorulama::new);
    }
}
